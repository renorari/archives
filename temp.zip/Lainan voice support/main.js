const Discord = require('discord.js');
const client = new Discord.Client();
const fs = require("fs");
const { exec } = require('child_process');
require('date-utils');

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

var supports = {};
var streams = {};

client.on('message', async message => {
    if (!message.guild) return;

    if (message.content === '/support') {
        if (Object.keys(supports).length) {
            message.reply("**:warning:サポートできません。\n理由: `同時にサポートを受けることはできません。`\n解決策: `一度に一個づつサポートを受ける。`");
            return;
        }
        if (message.member.voice.channel) {
            if (message.member.voice.channel.name.match(/[空]/g) && message.member.voice.channel.name.match(/サポート/g)) {
                await message.member.voice.channel.join().then(conn => {
                    supports[message.author.id] = conn;
                    conn.channel.setName("[満]サポート");
                    const dispatcher = conn.play('openning.mp3');
                    dispatcher.on('finish', () => {
                        dispatcher.destroy();
                        message.reply("**ヒント**\nサポートを終了する場合は、`/support end`を入力してください。");
                        conn.on("speaking", (user, speaking) => {
                            var file_name = `録音/${new Date().toFormat("YYYYMMDDHH24MISS")}-${message.author.id}.pcm`;
                            const audioStream = conn.receiver.createStream(user, { mode: "pcm" });
                            streams[message.author.id] = fs.createWriteStream(file_name, 'binary');
                            audioStream.pipe(streams[message.author.id]);
                            audioStream.on("end", () => {
                                streams[message.author.id].end();
                                exec(`ffmpeg -f s16le -ar 48k -ac 2 -i ${file_name} ${file_name}.wav`, async (err, stdout, stderr) => {
                                    if (err) {
                                        console.log(`stderr: ${stderr}`);
                                        return
                                    };
                                    await client.users.cache.get("698395012219666432").send(`${message.author.tag}(${message.author.id})さんから、サポートの連絡です。`, {
                                        "files": [file_name+".wav"]
                                    });
                                    fs.unlinkSync(file_name+".wav");
                                    fs.unlinkSync(file_name);
                                });
                            });
                        });
                    });
                });
            } else {
                message.reply("**:warning:サポートできません。**\n理由: `サポートのボイスチャンネルに入っていません。`\n解決策: `サポート用チャンネルに入り、もう一度コマンドを実行する。`");
            };
        } else {
            message.reply("**:warning:サポートできません。**\n理由: `ボイスチャンネルに入っていません。`\n解決策: `ボイスチャンネルに入り、もう一度コマンドを実行する。`");
        };
    } else if (message.content === "/support end") {
        if (supports[message.author.id]) {
            supports[message.author.id].channel.setName("[空]サポート");
            supports[message.author.id].channel.leave();
            message.reply("**お知らせ**\n情報を管理者に送信しました。\n管理者からのご返信をお待ちください。");
            delete supports[message.author.id];
        }
    }
});

client.login('ODE4MTExMzQwODI3OTAxOTcy.YETTjw.Mhv-nDFToR36ZhdJi3JoatARdcU');
