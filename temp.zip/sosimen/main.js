const Discord = require('discord.js');
const { createCanvas, loadImage, Image } = require('canvas');
const base64 = require('urlsafe-base64');
const client = new Discord.Client();

var codes = {};

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

function random_hira(N) {
    var S = "あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをん";
    return Array.from(Array(N)).map(() => S[Math.floor(Math.random() * S.length)]).join('');
};

async function create_img(code) {
    var canvas = createCanvas(480, 160);
    var ctx = canvas.getContext("2d");
    var bg = new Image;
    bg.src = "sm.png";
    ctx.font = "80px Ubuntu";
    ctx.fillStyle = "#c0c0e0";
    ctx.drawImage(bg, 0, 0, bg.width, bg.height);
    ctx.fillText(code, 6, 80 + 28);
    return base64.decode(canvas.toDataURL("image/png").split(",")[1]);
};

client.on('message', async message => {
    if (message.channel.id != "820199860238155788") return;
    if (message.author.bot) return;
    if (message.content.startsWith("a!")) {
        if (message.content == "a!ping") message.channel.send(`現在のPingは${client.ws.ping}msです。`);
        if (message.content == "a!help") message.channel.send({
            "embed": {
                "title": "認証の仕方",
                "description": "まず、`a!auth`を入力して、送られたメッセージと画像の手順に従って認証してください。\n認証するとメンバーロールが付き、同志になれます。",
                "color": 13632027,
                "footer": {
                    "icon_url": "https://cdn.discordapp.com/avatars/820143873841430558/8b455956e991e46fca3fb5d986ad99b4.png?size=512",
                    "text": "☭☭ 𝓣𝓱𝓲𝓷𝓴𝓲𝓷𝓰 𝓢𝓸𝓿𝓲𝓮𝓽 ☭☭"
                }
            }
        })
        if (message.content == "a!auth") {
            const code = random_hira(5);
            const img = await create_img(code);
            message.channel.send({
                "files": [img]
            });
            codes[message.author.id] = code;
        };
    } else if (codes[message.author.id] == message.content) {
        message.channel.send({
            "content": ":tada:",
            "embed": {
                "title": ":tada:認証成功:tada:",
                "description": "***おめでとうございます***\n認証に成功しました！",
                "color": 13632027,
                "footer": {
                    "icon_url": "https://cdn.discordapp.com/avatars/820143873841430558/8b455956e991e46fca3fb5d986ad99b4.png?size=512",
                    "text": "☭☭ 𝓣𝓱𝓲𝓷𝓴𝓲𝓷𝓰 𝓢𝓸𝓿𝓲𝓮𝓽 ☭☭"
                }
            }
        });
        message.member.roles.add("661232916906508304");
        message.guild.channels.cache.get("706892574903894087").send({
            "content": ":tada:",
            "embed": {
                "title": ":tada:新しい同志が正式に参加したよ！:tada:",
                "description": `新しい同志の<@${message.author.id}>が正式に参加しました！`,
                "color": 13632027,
                "footer": {
                    "icon_url": "https://cdn.discordapp.com/avatars/820143873841430558/8b455956e991e46fca3fb5d986ad99b4.png?size=512",
                    "text": "☭☭ 𝓣𝓱𝓲𝓷𝓴𝓲𝓷𝓰 𝓢𝓸𝓿𝓲𝓮𝓽 ☭☭"
                }
            }
        });
    };
});

client.login("ODIwMTQzODczODQxNDMwNTU4.YEw4gQ.1Ub9x42HYWm2X-u1498Np6BDZdU");